function selfVue(data, el, exp) {
    console.log(data, el, exp);
    var self = this
    this.vm = this
    this.data = data
    Object.keys(this.data).forEach(function (key) {
        self.proxyKeys(key)
    })
    console.log(this.data, 'this.data');
    console.log(this.data.name, 'this.data.name');
    console.log(this.name, 'this.name');
    
    observe(this.data)
    el.innerHTML = this.data[exp]
    new Watcher(this, exp, function (value) {
        console.log(value, 'value')
        el.innerHTML = value
    })
    console.log(this.data.name);
    // new Compile(options, this.vm)

    return this
}

selfVue.prototype = {
    proxyKeys: function (key) {
        var self = this
        Object.defineProperty(this, key, {
            enumerable: false,
            configurable: true,
            get: function proxyGetter() {
                return self.data[key]
            },
            set: function proxySetter(newVal) {
                self.data[key] = newVal
            }
        })
    }
}