function Watcher(vm, exp, cb) {
    console.log('编译节点后进入watcher');
    // console.log(vm, 'vmvmvmvmvmvm');
    // console.log(exp, 'expexpexpexpexpexpexpexp');
    // console.log(cb, 'cbcbcbcbcbcbcb');
    // console.log('watcher');
    this.cb = cb
    this.exp = exp
    this.vm = vm
    this.value = this.get()
}

Watcher.prototype = {
    update: function () {
        this.run()
    },
    run: function () {
        var value = this.vm.data[this.exp]
        console.log(value, 'value');
        var oldValue = this.value
        if (value !== oldValue) {
            this.value = value
            console.log(this.vm, value, oldValue, 'this.vm, value, oldValue');
            
            this.cb.call(this.vm, value)
        }
    },
    get: function () {
       Dep.target = this; // 缓存自己
       var value = this.vm.data[this.exp]
       Dep.target = null
       return value 
    }
}