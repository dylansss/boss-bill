function Compile(el, vm) {
    // console.log(el, vm);
    // console.log('执行编译器');
    this.vm = vm // 注意这里的this指compile,vm指selfVue对象
    this.el = document.querySelector(el)
    this.fragment = null
    this.init()
}

Compile.prototype = {
    init: function () {
        // console.log('dom节点的初始化');
        if (this.el) {
            this.fragment = this.nodeToFragment(this.el) // 将#app里的所有内容存到fragment里面
            this.compileElement(this.fragment)
            this.el.appendChild(this.fragment)
        } else {
            // console.log('dom节点不存在');
        }
    },
    nodeToFragment: function (el) {
        var fragment = document.createDocumentFragment() // 创建一个dom片段
        var child = el.firstChild // 第一个节点,包含文本和空格
        // console.log(fragment, el, el.firstChild);
        while (child) {
            // 将dom节点移入fragment片段
            fragment.appendChild(child)
            child = el.firstChild // 这里会遍历获取到el所有的child,打个问号?
        }
        return fragment
    },
    compileElement: function (el) {
        var childNodes = el.childNodes
        var self = this;
        [].slice.call(childNodes).forEach(function (node) { // childNodes是伪数组 [].slice.call()将其转化为数组遍历,获取到我们append进去的所有子节点(字符串片段和dom节点)详情参考https://zhidao.baidu.com/question/569766002.html
            // console.log(node, 'nodenodenodenode');
            var reg = /\{\{*(.*?)\}\}/
            var text = node.textContent
            if (self.isTextNode(node) && reg.test(text)) {
                // console.log(reg.exec(text), 'reg.exec(text)'); // 正则理解不够深,不懂...
                self.compileText(node, reg.exec(text)[1])
            }
            if (node.childNodes && node.childNodes.length) {
                self.compileElement(node)
            }
        })
    },
    compileText: function (node, exp) {
        var self = this
        var initText = this.vm[exp]
        this.updateText(node, initText)   // 将初始化的数据初始化到视图中
        new Watcher(this.vm, exp, function (value) {  // 生成订阅器并绑定更新函数
            self.updateText(node, value)
        })
    },
    updateText: function (node, value) {
        node.textContent = typeof value === 'underfind'? '': value
    },
    isTextNode: function (node) {
        // console.log(node.nodeType);
        return node.nodeType == 3 // div的nodeType === 1, div内的文本片段nodetype === 3
    }
}