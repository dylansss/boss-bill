function defineReactive(data, key, val) {
    observe(val)
    var dep = new Dep()
    Object.defineProperty(data, key, {
        enumerable: true,
        configurable: true,
        get: function () {
            if (Dep.target) {
                console.log('执行数据劫持-订阅');
                dep.addSub(Dep.target)
            }
            return val
        },
        set: function (newValue) {
            if (val === newValue) {
                return
            }
            val = newValue
            console.log(`属性${key}已经被监听了，现在值为${newValue.toString()}`);
            console.log('执行数据劫持-发布');
            dep.notify()
        }
    })
}

// Dep.target = null

function Dep() {
    this.subs = []
}

Dep.prototype ={
    addSub: function (sub) {
        console.log(sub, 'subvsubsubs');
        this.subs.push(sub)
    },
    notify: function () {
        console.log(this.subs);
        this.subs.forEach(function (sub) {
            console.log(sub);
            sub.update()
        })
    }
}
function observe(data) {
    if (!data || typeof data !== 'object') {
        return
    }
    Object.keys(data).forEach(function(key) {
        console.log(data, key, data[key])
        console.log('加入数据劫持');
        defineReactive(data, key, data[key])
    })
}
