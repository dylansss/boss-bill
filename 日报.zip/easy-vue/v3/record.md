# VUE双向绑定原理解析

**vue是采用MVVM模式实现双向绑定的，实现方式则是通过数据劫持结合发布者-订阅者模式的方式来实现的，而数据劫持主要通过 Object.defineProperty 来实现。**

## Object.defineProperty介绍

Object.defineProperty()可以来控制一个对象属性的一些特有操作，比如读写权、是否可以枚举，这里我们主要先来研究下它对应的两个描述属性get和set，

如下所示，通过Object.defineProperty()设置了对象Book的name属性，对其get和set进行重写操作，get就是在读取name属性这个值触发的函数，set就是在设置name属性这个值触发的函数，如下代码所示，当执行 Book.name = 'vue权威指南' 这个语句时，控制台会打印出 "你取了一个书名叫做vue权威指南"，紧接着，当读取这个属性时，就会输出 "《vue权威指南》"，

```javascript
var Book = {}
var name = '';
Object.defineProperty(Book, 'name', {
  set: function (value) {
    name = value;
    console.log('你取了一个书名叫做' + value);
  },
  get: function () {
    return '《' + name + '》'
  }
})
Book.name = 'vue权威指南';  // 你取了一个书名叫做vue权威指南
console.log(Book.name);  // 《vue权威指南》
```



## 思路分析

实现mvvm主要包含两个方面，数据变化更新视图，视图变化更新数据：

![1](http://tiebapic.baidu.com/forum/w%3D580/sign=48ea32c489510fb37819779fe933c893/541b6d1f95cad1c809a1805a683e6709c93d510e.jpg "1")

关键点在于data如何更新view，因为view更新data其实可以通过事件监听即可，比如input标签监听 'input' 事件就可以实现了。所以我们着重来分析下，当数据改变，如何更新视图的。

![2](http://tiebapic.baidu.com/forum/w%3D580/sign=d4aed71c18b30f24359aec0bf895d192/414addcad1c8a786663036737009c93d70cf500e.jpg "2")

数据更新视图的重点是如何知道数据变了，只要知道数据变了，那么接下去的事都好处理。如何知道数据变了，其实上文我们已经给出答案了，就是通过Object.defineProperty( )对属性设置一个set函数，当数据改变了就会来触发这个函数，所以我们只要将一些需要更新的方法放在这里面就可以实现data更新view了。

## 实现过程

我们已经知道实现数据的双向绑定，首先要对数据进行劫持监听，所以我们需要设置一个监听器Observer，用来监听所有属性。如果属性发上变化了，就需要告诉订阅者Watcher看是否需要更新。因为订阅者是有很多个，所以我们需要有一个消息订阅器Dep来专门收集这些订阅者，然后在监听器Observer和订阅者Watcher之间进行统一管理的。接着，我们还需要有一个指令解析器Compile，对每个节点元素进行扫描和解析，将相关指令对应初始化成一个订阅者Watcher，并替换模板数据或者绑定相应的函数，此时当订阅者Watcher接收到相应属性的变化，就会执行对应的更新函数，从而更新视图。因此接下去我们执行以下3个步骤，实现数据的双向绑定：

1. 实现一个监听器Observer，用来劫持并监听所有属性，如果有变动的，就通知订阅者。

2. 实现一个订阅者Watcher，可以收到属性的变化通知并执行相应的函数，从而更新视图。

3. 实现一个解析器Compile，可以扫描和解析每个节点的相关指令，并根据初始化模板数据以及初始化相应的订阅器。

![3](http://tiebapic.baidu.com/forum/w%3D580/sign=be94466955a7d933bfa8e47b9d4bd194/b59def86c9177f3ed62e807067cf3bc79f3d560e.jpg "3")


### 1. 实现一个Observer

监听器的作用就是去监听数据的每一个属性，我们上面也说了使用 Object.defineProperty 方法，当我们监听到属性发生变化之后我们需要通知 Watcher 订阅者执行更新函数去更新视图，在这个过程中我们可能会有很多个订阅者 Watcher 所以我们要创建一个容器 Dep 去做一个统一的管理。

```javascript
function defineReactive(data, key, val) {
    observe(val); // 递归遍历所有子属性
    Object.defineProperty(data, key, {
        enumerable: true,
        configurable: true,
        get: function() {
            return val;
        },
        set: function(newVal) {
            val = newVal;
            console.log('属性' + key + '已经被监听了，现在值为：“' + newVal.toString() + '”');
        }
    });
}
function observe(data) {
    if (!data || typeof data !== 'object') {
        return;
    }
    Object.keys(data).forEach(function(key) {
        defineReactive(data, key, data[key]);
    });
};
var library = {
    book1: {
        name: ''
    },
    book2: ''
};
observe(library);
library.book1.name = 'vue权威指南'; // 属性name已经被监听了，现在值为：“vue权威指南”
library.book2 = '没有此书籍';  // 属性book2已经被监听了，现在值为：“没有此书籍”
```
思路分析中，需要创建一个可以容纳订阅者的消息订阅器Dep，订阅器Dep主要负责收集订阅者，然后再属性变化的时候执行对应订阅者的更新函数。所以显然订阅器需要有一个容器，这个容器就是list，将上面的Observer稍微改造下，植入消息订阅器：
```javascript
function defineReactive(data, key, val) {
    observe(val); // 递归遍历所有子属性
    var dep = new Dep(); 
    Object.defineProperty(data, key, {
        enumerable: true,
        configurable: true,
        get: function() {
            if (是否需要添加订阅者) {
                dep.addSub(watcher); // 在这里添加一个订阅者
            }
            return val;
        },
        set: function(newVal) {
            if (val === newVal) {
                return;
            }
            val = newVal;
            console.log('属性' + key + '已经被监听了，现在值为：“' + newVal.toString() + '”');
            dep.notify(); // 如果数据变化，通知所有订阅者
        }
    });
}
function Dep () {
    this.subs = [];
}
Dep.prototype = {
    addSub: function(sub) {
        this.subs.push(sub);
    },
    notify: function() {
        this.subs.forEach(function(sub) {
            sub.update();
        });
    }
};
function observe(data) {
    if (!data || typeof data !== 'object') {
        return;
    }
    Object.keys(data).forEach(function(key) {
        defineReactive(data, key, data[key]);
    });
};
```

从代码上看，我们将订阅器Dep添加一个订阅者设计在getter里面，这是为了让Watcher初始化进行触发，因此需要判断是否要添加订阅者，至于具体设计方案，下文会详细说明的。在setter函数里面，如果数据变化，就会去通知所有订阅者，订阅者们就会去执行对应的更新的函数。到此为止，一个比较完整Observer已经实现了，接下来我们开始设计Watcher。

### 2. 实现watcher

订阅者Watcher在初始化的时候需要将自己添加进订阅器Dep中，那该如何添加呢？我们已经知道监听器Observer是在get函数执行了添加订阅者Wather的操作的，所以我们只要在订阅者Watcher初始化的时候触发对应的get函数去执行添加订阅者操作即可，那要如何触发get的函数，再简单不过了，只要获取对应的属性值就可以触发了，核心原因就是因为我们使用了Object.defineProperty()进行数据监听。这里还有一个细节点需要处理，我们只要在订阅者Watcher初始化的时候才需要添加订阅者，所以需要做一个判断操作，因此可以在订阅器上做一下手脚：在Dep.target上缓存下订阅者，添加成功后再将其去掉就可以了。订阅者Watcher的实现如下：

```javascript
function Watcher(vm, exp, cb) {
    this.cb = cb;
    this.vm = vm;
    this.exp = exp;
    this.value = this.get();  // 将自己添加到订阅器的操作
}
Watcher.prototype = {
    update: function() {
        this.run();
    },
    run: function() {
        var value = this.vm.data[this.exp];
        var oldVal = this.value;
        if (value !== oldVal) {
            this.value = value;
            this.cb.call(this.vm, value, oldVal);
        }
    },
    get: function() {
        Dep.target = this;  // 缓存自己
        var value = this.vm.data[this.exp]  // 强制执行监听器里的get函数
        Dep.target = null;  // 释放自己
        return value;
    }
};
```

再对observe做一下调整

```javascript
function defineReactive(data, key, val) {
    observe(val); // 递归遍历所有子属性
    var dep = new Dep(); 
    Object.defineProperty(data, key, {
        enumerable: true,
        configurable: true,
        get: function() {
            if (Dep.target) {.  // 判断是否需要添加订阅者
                dep.addSub(Dep.target); // 在这里添加一个订阅者
            }
            return val;
        },
        set: function(newVal) {
            if (val === newVal) {
                return;
            }
            val = newVal;
            console.log('属性' + key + '已经被监听了，现在值为：“' + newVal.toString() + '”');
            dep.notify(); // 如果数据变化，通知所有订阅者
        }
    });
}
Dep.target = null;
```

到此为止，简单版的Watcher设计完毕，这时候我们只要将Observer和Watcher关联起来，就可以实现一个简单的双向绑定数据了。因为这里没有还没有设计解析器Compile，所以对于模板数据我们都进行写死处理，假设模板上又一个节点，且id号为'name'，并且双向绑定的绑定的变量也为'name'，且是通过两个大双括号包起来（这里只是为了演示，暂时没什么用处），模板如下：
```html
<body>
    <h1 id="name">{{name}}</h1>
</body>
```
这时候我们需要将Observer和Watcher关联起来：
```javascript
function SelfVue (data, el, exp) {
    this.data = data;
    observe(data);
    el.innerHTML = this.data[exp];  // 初始化模板数据的值
    new Watcher(this, exp, function (value) {
        el.innerHTML = value;
    });
    return this;
}
```

然后在页面上new以下SelfVue类，就可以实现数据的双向绑定了：

```javascript
<body>
    <h1 id="name">{{name}}</h1>
</body>
<script src="js/observer.js"></script>
<script src="js/watcher.js"></script>
<script src="js/index.js"></script>
<script type="text/javascript">
    var ele = document.querySelector('#name');
    var selfVue = new SelfVue({
        name: 'hello world'
    }, ele, 'name');
    window.setTimeout(function () {
        console.log('name值改变了');
        selfVue.data.name = 'canfoo';
    }, 2000);
</script>
```

这时候打开页面，可以看到页面刚开始显示了是'hello world'，过了2s后就变成'canfoo'了。到这里，总算大功告成一半了，但是还有一个细节问题，我们在赋值的时候是这样的形式 '  selfVue.data.name = 'canfoo'  ' 而我们理想的形式是'  selfVue.name = 'canfoo'  '为了实现这样的形式，我们需要在new SelfVue的时候做一个代理处理，让访问selfVue的属性代理为访问selfVue.data的属性，实现原理还是使用Object.defineProperty( )对属性值再包一层：

```javascript
function SelfVue (data, el, exp) {
    var self = this;
    this.data = data;
    Object.keys(data).forEach(function(key) {
        self.proxyKeys(key);  // 绑定代理属性
    });
    observe(data);
    el.innerHTML = this.data[exp];  // 初始化模板数据的值
    new Watcher(this, exp, function (value) {
        el.innerHTML = value;
    });
    return this;
}
SelfVue.prototype = {
    proxyKeys: function (key) {
        var self = this;
        Object.defineProperty(this, key, {
            enumerable: false,
            configurable: true,
            get: function proxyGetter() {
                return self.data[key];
            },
            set: function proxySetter(newVal) {
                self.data[key] = newVal;
            }
        });
    }
}
```

### 3.实现Compile（仅实现最基础的{{}}中变量替换指令）

**实现一个解析器Compile，用来做解析和绑定工作。解析器Compile实现步骤：**

1. 解析模板指令，并替换模板数据，初始化视图

2. 将模板指令对应的节点绑定对应的更新函数，初始化相应的订阅器

```javascript
function Compile(el, vm) {
    this.vm = vm // 注意这里的this指compile,vm指selfVue对象
    this.el = document.querySelector(el)
    this.fragment = null
    this.init()
}

Compile.prototype = {
    init: function () {
        if (this.el) {
            this.fragment = this.nodeToFragment(this.el) // 将#app里的所有内容存到fragment里面
            this.compileElement(this.fragment)
            this.el.appendChild(this.fragment)
        } else {
        }
    },
    nodeToFragment: function (el) {
        var fragment = document.createDocumentFragment() // 创建一个dom片段
        var child = el.firstChild // 第一个节点,包含文本和空格
        while (child) {
            // 将dom节点移入fragment片段
            fragment.appendChild(child)
            child = el.firstChild // 这里会遍历获取到el所有的child,打个问号?
        }
        return fragment
    },
    compileElement: function (el) {
        var childNodes = el.childNodes
        var self = this;
        [].slice.call(childNodes).forEach(function (node) { // childNodes是伪数组 [].slice.call()将其转化为数组遍历,获取到我们append进去的所有子节点(字符串片段和dom节点)详情参考https://zhidao.baidu.com/question/569766002.html
            var reg = /\{\{*(.*?)\}\}/
            var text = node.textContent
            if (self.isTextNode(node) && reg.test(text)) {
                self.compileText(node, reg.exec(text)[1])
            }
            if (node.childNodes && node.childNodes.length) {
                self.compileElement(node)
            }
        })
    },
    compileText: function (node, exp) {
        var self = this
        var initText = this.vm[exp]
        this.updateText(node, initText)   // 将初始化的数据初始化到视图中
        new Watcher(this.vm, exp, function (value) {  // 生成订阅器并绑定更新函数
            self.updateText(node, value)
        })
    },
    updateText: function (node, value) {
        node.textContent = typeof value === 'underfind'? '': value
    },
    isTextNode: function (node) {
        return node.nodeType == 3 // div的nodeType === 1, div内的文本片段nodetype === 3
    }
}
```

为了将解析器Compile与监听器Observer和订阅者Watcher关联起来，我们需要再修改一下类SelfVue函数：
```javascript
function SelfVue (options) {
    var self = this;
    this.vm = this;
    this.data = options;
    Object.keys(this.data).forEach(function(key) {
        self.proxyKeys(key);
    });
    observe(this.data);
    new Compile(options, this.vm);
    return this;
}
```

更改后，我们就不要像之前通过传入固定的元素值进行双向绑定了，可以随便命名各种变量进行双向绑定了：

```javascript
<body>
    <div id="app">
        <h2>{{title}}</h2>
        <h1>{{name}}</h1>
    </div>
</body>
<script src="js/observer.js"></script>
<script src="js/watcher.js"></script>
<script src="js/compile.js"></script>
<script src="js/index.js"></script>
<script type="text/javascript">
    var selfVue = new SelfVue({
        el: '#app',
        data: {
            title: 'hello world',
            name: ''
        }
    });
    window.setTimeout(function () {
        selfVue.title = '你好';
    }, 2000);
    window.setTimeout(function () {
        selfVue.name = 'canfoo';
    }, 2500);
</script>
```



### 4.完善compile其余指令

到上一步，一个数据双向绑定功能已经基本完成了，接下去就是需要完善更多指令的解析编译，在哪里进行更多指令的处理呢？答案很明显，只要在上文说的compileElement函数加上对其他指令节点进行判断，然后遍历其所有属性，看是否有匹配的指令的属性，如果有的话，就对其进行解析编译。这里我们再添加一个v-model指令和事件指令的解析编译，对于这些节点我们使用函数compile进行解析处理：

```javascript
function Compile(el, vm) {
    // console.log(el, vm);
    // console.log('执行编译器');
    this.vm = vm // 注意这里的this指compile,vm指selfVue对象
    this.el = document.querySelector(el)
    this.fragment = null
    this.init()
}

Compile.prototype = {
    init: function () {
        // console.log('dom节点的初始化');
        if (this.el) {
            this.fragment = this.nodeToFragment(this.el) // 将#app里的所有内容存到fragment里面
            this.compileElement(this.fragment)
            this.el.appendChild(this.fragment)
        } else {
            // console.log('dom节点不存在');
        }
    },
    nodeToFragment: function (el) {
        var fragment = document.createDocumentFragment() // 创建一个dom片段
        var child = el.firstChild // 第一个节点,包含文本和空格
        // console.log(fragment, el, el.firstChild);
        while (child) {
            // 将dom节点移入fragment片段
            fragment.appendChild(child)
            child = el.firstChild // 这里会遍历获取到el所有的child,打个问号?
        }
        return fragment
    },
    compileElement: function (el) {
        var childNodes = el.childNodes
        var self = this;
        [].slice.call(childNodes).forEach(function (node) { // childNodes是伪数组 [].slice.call()将其转化为数组遍历,获取到我们append进去的所有子节点(字符串片段和dom节点)详情参考https://zhidao.baidu.com/question/569766002.html
            // console.log(node, 'nodenodenodenode');
            var reg = /\{\{*(.*?)\}\}/
            var text = node.textContent
            if (self.isElementNode(node)) {
                self.compile(node);
            } else if (self.isTextNode(node) && reg.test(text)) {
                // console.log(reg.exec(text), 'reg.exec(text)'); // 正则理解不够深,不懂...
                self.compileText(node, reg.exec(text)[1])
            }
            if (node.childNodes && node.childNodes.length) {
                self.compileElement(node)
            }
        })
    },
    compile: function (node) {
        var nodeAttrs = node.attributes
        var self = this
        Array.prototype.forEach.call(nodeAttrs, function(attr){
            var attrName = attr.name
            if (self.isDirective(attrName)) {
                var exp = attr.value
                var dir = attrName.substring(2)
                if (self.isEventDirective(dir)) { // 事件指令
                    self.compileEvent(node, self.vm, exp, dir)
                } else { // v-model指令
                    self.compileModel(node, self.vm, exp, dir)
                }
                node.removeAttribute(attrName)
            }
        })
    },
    compileText: function (node, exp) {
        var self = this
        var initText = this.vm[exp]
        this.updateText(node, initText)   // 将初始化的数据初始化到视图中
        new Watcher(this.vm, exp, function (value) {  // 生成订阅器并绑定更新函数
            self.updateText(node, value)
        })
    },
    compileEvent: function (node, vm, exp, dir) {
        var eventType = dir.split(':')[1]
        var cb = vm.methods && vm.methods[exp]
        if (eventType && cb) {
            node.addEventListener(eventType, cb.bind(vm), false)
        }
    },
    compileModel: function (node, vm, exp, dir) {
        var self = this
        var val = this.vm[exp]
        this.modelUpdater(node, val)
        new Watcher(this.vm, exp, function (value) {
            self.modelUpdater(node, value)
        })

        node.addEventListener('input', function (e) {
            var newValue = e.target.value
            if (val === newValue) {
                return
            }
            self.vm[exp] = newValue
            val = newValue
        })
    },
    updateText: function (node, value) {
        node.textContent = typeof value === 'underfind'? '': value
    },
    modelUpdater: function (node, value) {
        node.value = typeof value === 'underfind'? '': value
    },
    isDirective: function(attr) {
        return attr.indexOf('v-') == 0;
    },
    isEventDirective: function(dir) {
        return dir.indexOf('on:') === 0;
    },
    isElementNode: function (node) {
        return node.nodeType == 1;
    },
    isTextNode: function (node) {
        // console.log(node.nodeType);
        return node.nodeType == 3 // div的nodeType === 1, div内的文本片段nodetype === 3
    }
}
```
在稍微改造下类SelfVue，使它更像vue的用法：
```javascript
function SelfVue(options) {
    // console.log(data, el, exp);
    var self = this
    this.data = options.data
    this.methods = options.methods

    Object.keys(this.data).forEach(function (key) {
        self.proxyKeys(key)
    })
    // 数据加入数据劫持
    observe(this.data)
    // 执行编译器
    new Compile(options.el, this)
    // return this
    options.mounted.call(this) // 所有事情处理好后执行mounted函数
}

SelfVue.prototype = {
    proxyKeys: function (key) {
        var self = this
        Object.defineProperty(this, key, {
            enumerable: false,
            configurable: true,
            get: function proxyGetter() {
                return self.data[key]
            },
            set: function proxySetter(newVal) {
                self.data[key] = newVal
            }
        })
    }
}
```
在页面上设置如下
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- <div id="name"></div> -->
    <div id="app">
        <div class="title">{{title}}</div>
        <div class="name">{{name}}</div>
        <input type="text" v-model="name">
        <button v-on:click="clickMe">这是个按钮</button>
    </div>
    <script src="./obServer.js"></script>
    <script src="./Watcher.js"></script>
    <script src="./compile.js"></script>
    <script src="./index.js"></script>
    <script type="text/javascript">
        new SelfVue({
            el: '#app',
            data: {
                title: '这是个标题',
                name: '',
            },
            methods: {
                clickMe: function () {
                    this.title = '标题要变'
                    this.name = '行三'
                }
            },
            mounted: function () {
                window.setTimeout(() => {
                    console.log('name的值变了');
                    this.title = '标题变了'
                    this.name = '张三'
                    console.log(this.title);
                    console.log(this.name);
                }, 1000)
            }
        })

    </script>
</body>
</html>
```